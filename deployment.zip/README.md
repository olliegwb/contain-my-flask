# contained-python

This is a simple Python/Flask 'Hello World' app created for workshop examples.
